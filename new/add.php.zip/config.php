<?php

$config['dbServer'] = 'localhost';
$config['db'] = 'oneclini_editor2';
$config['dbUser'] = 'oneclini_editor2';
$config['dbPass'] = '^o_6.VZav;uG';

$config['client'] = '1';

$config['enable_categories'] = '1';

$config['AppLocation'] = '/editor/';
$config['AppURL'] = 'http://1clinic.ca'.$config['AppLocation'];


$config['login'] = 'admin';
$config['password'] = 'admin';


?>